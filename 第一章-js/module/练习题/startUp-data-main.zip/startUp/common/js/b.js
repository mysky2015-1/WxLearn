define(function (require, exports, module) {
	var sex = "男";
	console.log("===b.js===");
	return {
		sex: sex,
	}
});