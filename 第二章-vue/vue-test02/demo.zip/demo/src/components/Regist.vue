<template>
  <div class="regist">
    <h1>{{msg}}</h1>
    <h2>这是个Regist页面</h2>
  </div>
</template>

<script>
export default {
  name: 'regist',
  data () {
    return {
      msg: '注册需要加一下用户，密码等信息'
    }
  }
}
</script>
